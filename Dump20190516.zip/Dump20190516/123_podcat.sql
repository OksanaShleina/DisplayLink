CREATE DATABASE  IF NOT EXISTS `123` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `123`;
-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: 123
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `podcat`
--

DROP TABLE IF EXISTS `podcat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `podcat` (
  `Id` int(11) DEFAULT NULL,
  `Id_Podmat` int(11) DEFAULT NULL,
  `подподМат` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `podcat`
--

LOCK TABLES `podcat` WRITE;
/*!40000 ALTER TABLE `podcat` DISABLE KEYS */;
INSERT INTO `podcat` VALUES (1,1,'Железобетон'),(2,1,'Бетон на гравии или щебне из природного камня'),(3,2,'Туфобетон'),(4,2,'Пемзобетон'),(5,2,'Бетон на вулканическом шлаке'),(6,3,'Керамзитобетон на керамзитовом песке и керамзитопенобетон'),(7,3,'Керамзитобетон на кварцевом песке с поризацией'),(8,3,'Керамзитобетон на перлитовом песке'),(9,4,'Газо- и пенобетон газо- и пеносиликат'),(10,4,'Газо- и пенозолобетон'),(11,5,'Цементно-песчаный'),(12,5,'Сложный (песок, известь, цемент)'),(13,5,'Известково-песчаный'),(14,6,'Глиняного обыкновенного (ГОСТ 530-80) на цементно-песчаном растворе'),(15,6,'Глиняного обыкновенного на цементно-шлаковом растворе'),(16,6,'Глиняного обыкновенного на цементно-перлитовом растворе'),(17,7,'Керамического плотностью 1400 кг/м3 (брутто) на цементно-песчаном растворе'),(18,7,'Силикатного одиннадцатипустотного на цементно-песчаном растворе'),(19,7,'Силикатного четырнадцатипустотного на цементно-песчаном растворе'),(20,17,'Гранит, гнейс и базальт'),(21,17,'Мрамор'),(22,17,'Известняк'),(23,8,'Сосна и ель поперек волокон (ГОСТ 8486-66**, ГОСТ 9463-72*)'),(24,8,'Сосна и ель  вдоль волокон'),(25,8,' Картон облицовочный'),(26,9,' Маты минераловатные прошивные (ГОСТ 21880-76) и на синте- тическом связующем'),(27,9,' Плиты полужесткие минераловатные на крахмальном связующем'),(28,9,' Маты и полосы из стеклянного волокна  прошивные'),(29,10,'Пенополистирол (ГОСТ 15588-70)'),(30,10,'Пенопласт  ПХВ-1'),(31,10,'Перлитопластбетон'),(32,11,' Гравий керамзитовый'),(33,11,' Гравий шунгизитовый'),(34,11,' Песок для строительных работ'),(35,12,'Пеностекло или газостекло'),(36,13,'Листы асбестоцементные плоские'),(37,14,'Битумы нефтяные строительные и кровельные'),(38,14,' Асфальтобетон'),(39,14,'Рубероид'),(40,15,'Линолеум поливинилхлоридный многослойный'),(41,15,'Линолеум поливинилхлоридный на тканевой подоснове'),(42,16,' Сталь стержневая арматурная'),(43,16,'Чугун'),(44,16,'Алюминий');
/*!40000 ALTER TABLE `podcat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 16:02:59
